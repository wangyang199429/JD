public class Demo {
    public void test() {
    System.out.println("Hello");
      if (true) {
    System.out.println("World");
      }
    }
    }
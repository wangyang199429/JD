public class Sutdent {
   //tab就是全部接受 esc是拒绝接受  ctrl + -> 部分接受
    private String name;
    private int age;
    private String sex;
    // 添加一个方法，用于获取学生的姓名
    // asdadadadadadadadadadadakjsdkajdka
    
    

}

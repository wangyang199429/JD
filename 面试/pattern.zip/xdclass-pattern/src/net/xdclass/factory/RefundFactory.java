package net.xdclass.factory;

/**
 * 退款抽象接口
 */
public interface RefundFactory {

    /**
     * 退款
     */
    void refund();
}

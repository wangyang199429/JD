//package net.xdclass.factory.method;
//
//import net.xdclass.factory.PayFactory;
//
///**
// * 抽象工厂方法
// */
//public interface PayFactory {
//
//    PayFactory getPay();
//}

package net.xdclass.adapter.api;

/**
 * 小滴课堂,愿景：让技术不再难学
 *
 * @Description
 * @Author 二当家小D
 * @Remark 有问题直接联系我，源码-笔记-技术交流群
 * @Version 1.0
 **/

public class PayGatewayAdapter implements PayGateway {

    @Override
    public void unifiedorder() {

    }

    @Override
    public void refund() {

    }

    @Override
    public void query() {

    }

    @Override
    public void sendRedPack() {

    }
}

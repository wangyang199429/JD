package net.xdclass.observe;

public interface Observer {

    /**
     * 观察到消息后进行的操作，就是响应
     */
    void update();
}

package net.xdclass.proxy;

/**
 * 抽取公共的方法
 */
public interface DigitalSell {

    void sell();
}

package net.xdclass.bridge;


public interface Color {

    void useColor();
}
